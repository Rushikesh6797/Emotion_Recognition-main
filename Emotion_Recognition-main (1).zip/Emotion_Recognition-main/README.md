# Emotion_Recognition
python -m pip install --upgrade pip

python -m pip install --upgrade opencv-python
python -m pip install --upgrade numpy
python -m pip install --upgrade pandas
python -m pip install --upgrade matplotlib
python -m pip install --upgrade scikit-learn
python -m pip install --upgrade scipy



pip install moviepy==1.0.0
pip install ffmpeg
pip install tensorflow
pip install tensorflow-gpu
pip install opencv-contrib-python
//python -m pip install --upgrade fer

pip install fer==22.4.0
 